//
//  Pet.swift
//  RandomPetImagesHW
//
//  Created by Akeel Al-Ead on 21/11/2021.
//

import Foundation

struct Pet : Decodable {
    let message : String
    let status : String
}
